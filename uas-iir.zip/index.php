<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PawSearch</title>
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&family=Pacifico&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
  <style>
    /* CSS untuk custom alert (opsional) */
    #customAlert {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background-color: rgba(0, 0, 0, 0.5);
      width: 100%;
      height: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 1000;
    }

    .alert-box {
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
      text-align: center;
    }

    .alert-box button {
      background-color: #ff6ba6;
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="container">
    <img src="img/logo-iir.png" style="width:40%;">
    <form method="post" action="result.php" onsubmit="return validateForm()"> 
      <div class="search-bar">
        <input type="text" placeholder="Search here..." id="search-box" name="keyword" autocomplete="off">
        <button type="submit" id="search-btn" name="search">Go</button>
      </div>
      <div class="options">
        <div class="source-section">
          <span class="label">Source:</span>
          <div class="checkboxes">
            <label>
              <input type="checkbox" name="x" value="x">
              X
            </label>
            <label>
              <input type="checkbox" name="ig" value="instagram">
              Instagram
            </label>
            <label>
              <input type="checkbox" name="youtube" value="youtube">
              YouTube
            </label>
          </div>
        </div>
        <div class="method-section">
          <span class="label">Method:</span>
          <div class="radio-buttons">
            <label>
              <input type="radio" name="method" value="jaccard">
              Jaccard
            </label>
            <label>
              <input type="radio" name="method" value="cosine">
              Cosine
            </label>
          </div>
        </div>
      </div>
    </form>
  </div>

  <div id="customAlert" style="display: none;"> 
    <div class="alert-box">
      <p id="alertMessage"></p>
      <button onclick="hideAlert()">OK</button>
    </div>
  </div>

  <script>
    function validateForm() {
      var keyword = document.getElementById("search-box").value;
      var x = document.querySelector('input[name="x"]:checked');
      var ig = document.querySelector('input[name="ig"]:checked');
      var youtube = document.querySelector('input[name="youtube"]:checked');
      var method = document.querySelector('input[name="method"]:checked');

      if (keyword == "" || (!x && !ig && !youtube) || !method) {
        showAlert("Harap isi semua field."); 
        return false; // Mencegah form disubmit
      }
      return true; // Melanjutkan submit form
    }

    function showAlert(message) {
      document.getElementById("alertMessage").innerText = message;
      document.getElementById("customAlert").style.display = "flex";
    }

    function hideAlert() {
      document.getElementById("customAlert").style.display = "none";
    }
  </script>
</body>
</html>